import logo from './logo.svg';
import './App.css';
import Data from './components/Data';

function App() {
  return (
    <div className="border-2 border-black ">
     

      <div>
        <Data/>
      </div>
      
    </div>
  );
}

export default App;
