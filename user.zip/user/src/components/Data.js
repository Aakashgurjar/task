import React, { use, useEffect, useState } from 'react'
import axios from 'axios';
import { FaStar } from "react-icons/fa";

const Data = () => {


     const [products , setproduct ] = useState([]);

     const GetData = async () => {
        

       const {data} = await axios.get( "https://dummyjson.com/products")
       console.log( data.products );
       setproduct(data.products);

     }

     useEffect( () => {
      GetData();
     } , [])



  return (
    <div>
      
      {

       <div >
       <h2 className="text-xl font-bold mb-4 flex justify-center items-center mt-5">Product List</h2>
       <ul>
         {
         products.map( product => (

           <li key={product.id} className="mb-2 border p-3 rounded shadow ">
             <h3 className=" flex justify-center items-center text-lg font-semibold  underline">{product.title}</h3>
             <p className='flex justify-center items-center text-green-600 font-bold'>Price: ${product.price}</p>
             <div className='flex justify-center items-center'> 
                <img src={product.thumbnail} alt={product.title} width="250" />
               
               <div className='  ml-5'>
                <div className='flex justify-start gap-2  '>
                <FaStar className='text-yellow-400 ml-1 mt-1'/>
                <h5 className='font-semibold'> {product.rating} </h5>
                </div>
               
               <p className='font-semibold'>
                  { product.description }
                </p>

               </div>
                
                
             </div>
           </li>
         ))}
       </ul>
     </div>
      }


               

    </div>
  )
}

export default Data

